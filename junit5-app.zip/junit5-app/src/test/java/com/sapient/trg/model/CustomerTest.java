package com.sapient.trg.model;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;


import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import static java.time.Duration.ofMillis;

/*  junit4: @Before, junit5: @BeforeEach
  junit4: @After, junit5: @AfterEach
  junit4: @BeforeClass, junit5: @BeforeAll
  junit4: @AfterClass, junit5: @AfterAll
  junit4: @Ignore, junit5: @Disabled
 */
class CustomerTest {
	private Customer customer;
	
	@BeforeAll
	public static void beforeClass() {
		System.out.println("Before class initialization");
	}
	
	@AfterAll
	public static void afterClass() {
		System.out.println("After class clean-up");
	}

	@BeforeEach
	public void initializeCustomer() {
		customer=new Customer(1,"Smith",
				LocalDate.of(1990,10,15),9878987879L,"smith@sapient.com");
	}
	
	@Test
	void testGetCustomerId() {
		assertEquals("1",customer.getCustomerId().toString());
	}

	@Test
	void testGetCustomerName() {
		assertEquals("Smith",customer.getCustomerName());
	}

	@Test
	void testGetBirthdateForNull() {
		customer.setBirthdate(null);
		Assertions.assertThrows(NullPointerException.class, 
									()->customer.getBirthdate());
	}

	@Disabled
	@Test
	void testGetMobile() {
		fail("Not yet implemented");
	}

	@Test
	void testGetEmailForTimeOut() {
		Assertions.assertTimeout(ofMillis(500),
				()->customer.getEmail());
	}

}
