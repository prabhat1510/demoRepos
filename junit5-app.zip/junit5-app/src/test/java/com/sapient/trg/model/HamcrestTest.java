package com.sapient.trg.model;

import static org.hamcrest.Matchers.arrayContaining;
import static org.hamcrest.Matchers.arrayWithSize;
import static org.hamcrest.Matchers.endsWith;
import static org.hamcrest.Matchers.everyItem;
import static org.hamcrest.Matchers.greaterThanOrEqualTo;
import static org.hamcrest.Matchers.hasItems;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.isEmptyOrNullString;
import static org.hamcrest.Matchers.isEmptyString;
import static org.hamcrest.Matchers.lessThan;
import static org.junit.Assert.assertThat;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;

public class HamcrestTest {

	@Test
	public void test() {
		List<Integer> marksList= 
				Arrays.asList(89,96,69,75,95);
		assertThat(marksList,hasSize(5));
		assertThat(marksList,hasItems(96,69));
		assertThat(marksList,everyItem(lessThan(100)));
		assertThat(marksList,
				everyItem(greaterThanOrEqualTo(0)));
		
		//Strings
		assertThat(null, isEmptyOrNullString());
		assertThat("",isEmptyString());
		assertThat("com.sapient",endsWith("sapient"));
		
		//Arrays
		Integer [] marks= {89,90,45,87,39};
		assertThat(marks, arrayWithSize(5));
		assertThat(marks, arrayContaining(89,90,45,87,39));
		
		
		
	}

}
