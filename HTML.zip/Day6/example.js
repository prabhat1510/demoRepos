/**
 * JS if else and else if - Conditional Statements
 * 
 * 
 */

function checkEligibilityToVote(value){
    let eligibleToVote = "eligible to vote. Name is present in the voter list";
    let notEligibleToVote = "Name is not present in the voter list";
    let message;
    if(value>18){
        let msg="Hi you are ";
        message=msg+eligibleToVote;

    }else if(value==18){
        let msg1="Hi you are ";
        message=msg1+eligibleToVote;
        
    }else{
        message=notEligibleToVote;
                  
    
    }
    document.getElementById('id1').innerHTML=message; 
    
}

//Switch Case example
function switchCaseExample(val){
    let day;
    switch(new Date().getDay()){
        case 0: 
            day = "Sunday";
            break;
        case 1:
            day = "Monday";
            break;
        case 2:
            day = "Tuesday";
            break;
        default:
            day = "Every day is a good day";
            break;
    }
    document.getElementById('id2').innerHTML=day;
}    

//while and do while 
function whileLoopExample(){
    let counter=0;
    while(counter<20){
    //while(true){
        console.log(counter);

        counter++;
    }
    document.getElementById('id3').innerHTML=counter;
}    

function doWhileLoopExample(){
    let counter=0;
    do{
        //while(true){
            console.log('Value of counter is ----'+counter);
    
            counter++;
        }while(counter<20);
    document.getElementById('id4').innerHTML=counter;
} 


/** use of break and continue
 *  break statement "jumps out" of a loop.
 *  continue statement "jumps over" one iteration in the loop
*/

function useOfBreak(){
    let text='';
    let i;
    
    for (i=0;i<10;i++){
        if(i === 3){
            break;
        }
        text+='The numner is '+i+'<br>';
    }
    document.getElementById('id5').innerHTML=text;
} 
function useOfContinue(){
    let text='';
    let i;
    
    for (i=0;i<10;i++){
        if(i === 3){
            continue;
        }
        text+='The numner is '+i+'<br>';
    }
    document.getElementById('id6').innerHTML=text;
} 

/**
 * javascript data types:-
 *  1. string
 *  2. number
 *  3. boolean
 *  4. object
 *  5. function
 * 
 * There are 6 types of objects:
 * 1. Object
 * 2. Date
 * 3. Array
 * 4. String
 * 5. Number
 * 6. Boolean
 * 
 * 2 data types that cannot contain values:
 * 1. null
 * 2. undefined
 * 
 * typeOf operator or function which tells you the type of object or data
 * 
 * Converting Numbers to Strings
 * String()-String(123)
 * (123).toString()
 * 
 */
/**
 * Regular Expression:- It is a sequence of characters that forms a search pattern.
 * The search pattern can be used for text search and text replace operations
 * 
 * search() method uses an expression to search for a match, and returns the position of the match.
 * replace() method returns a modified string where the pattern is replaced
 */

 let str = "Happy Diwali";
 let n =  str.search(/Diwali/i);
 document.getElementById('id7').innerHTML='Value of search returned is ----'+n;
 let m =  str.replace('Diwali','Holi');
 document.getElementById('id8').innerHTML='Value of search returned is ----'+m;

 /**
  * ES2015 has introduced two important new keywords let and const . These two keywords provide Block Scope
  * variables(and constants) in JS.
  * Before 2015 JS had only two types of scope:- Global and Function scope
  */
 var empName='Donald';

 function myFunction(){
     //function scope
    var empLastName = 'Trump';
    document.getElementById('id9').innerHTML='I can display empName---'+empName+'---empLastName---'+empLastName;
 }
 //empLastName variable is not accessible outside function
 //document.getElementById('id10').innerHTML='---empLastName---'+empLastName;
 //Block scope
{
    var y=15;
    let z=20;
    const c=15;
    //c=c*10; // Value of variable constant cannot be changed.
    document.getElementById('id10').innerHTML='---block scope of z---'+z+'----'+y+'------------------'+c*10;
    //Constant Objects can change
    const emp={fName:'DONALD',lName:'TRUMPH'};
    emp.sal=15000;
    emp.fName='PRABHAT';
    document.getElementById('id11').innerHTML=emp.sal+'-------------'+emp.fName;
}
//document.getElementById('id10').innerHTML='---block scope of z---'+z;

/**
* Arrow Function- Introduced in ES6
* It allows us to write shorter function syntax
*/
var hello;
hello=function(){
    return 'Happy Festivals';
}

document.getElementById('id12').innerHTML=hello;
/**
greeting= () =>{
    return 'Happy Festivals using Arrow Function';
}
 */

greeting= () =>'Happy Festivals using Arrow Function';

document.getElementById('id13').innerHTML=greeting;


message=(val)=>"Hello"+val;
document.getElementById('id14').innerHTML=message('Reschedule the classes');


/**
 * JS Function Call,Apply,Closures
 * OOPS in JS
 * Async- Callbacks,Asynchronous,Promises,Async/wait
 */