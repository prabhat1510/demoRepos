function validateForm (loginForm) {
    validateUserName(loginForm.login_name);    
    validatePassword(loginForm.login-pass);

}



function validateUserName(username) {
  let letters = /^[A-Za-z]+$/;
  if (username.length < 5)
    return false ;
  if (username.value.match(letters)) {
    // alert("Your name have accepted : you can try another");
    return true;
  } else {
    alert("Please input alphabet characters only");
    return false;
  }
}

function validatePassword( password ) {
    if ( password.length < 8 )
        return false;

    let regularExpression = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$/;

    if (password.value.match(regularExpression)) {
        // alert("Success");
        return true;
    } else {
        alert("Please follow the instructions for password");
        return false;
    }
}
