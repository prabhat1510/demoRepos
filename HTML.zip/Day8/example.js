/**
 * OOPS in JS
 * Async- Callbacks,Asynchronous,Promises,Async/wait
 * 
 * ES6 or ECMAScript 2015 it introduces JavaScript classes
 * JS classes are templates for JS objects. or you can classes are blue print of an object
 */
//Car class is not an object its a template for JS objects
 class Car{
    /**name:"Volvo",
    engine:"2500CC",
    model:"Sedan",
    mfgYr:2020**/
    /**
     * This constructor method is a special method:
     * It has to have the exact name "constructor"
     * It is executed automatically when a new object is created
     * It is used to intialize object properties
     * @param {*} name 
     * @param {*} engine 
     * @param {*} model 
     * @param {*} mfgYr 
     */
    constructor(name,engine,model,mfgYr){
        this.name=name;
        this.engine=engine;
        this.model=model;
        this.mfgYr=mfgYr;
          
    }
    //You can add any number of methods along with constuctor methods inside class
    getName(){
        return this.name;
    }
    setName(name){
        this.name=name;
    }
    getEngine(){
        return this.engine;
    }
    setEngine(engine){
        this.engine=engine;
    }

    getModel(){
        return this.model;
    }
    setModel(model){
        this.model=model;
    }
    getMfgYr(){
        return this.mfgYr;
    }
    setMfgYr(mfgYr){
        this.mfgYr=mfgYr;
    }


    ageOfCar(){
        let date=new Date();
        let age=date.getFullYear()-this.mfgYr;
        return age;
    }
}

//Using new keyword we are creating objects of class Car. car1 and car2 are two different objects of type Car
let car1=new Car("Volvo","2500CC","Sedan","2020"); //When a new object is created a constructor method is called.
let car2=new Car("BMW","3000CC","Sports","2019");
//Using getter and setter methods we are trying hide the data. This is also known as Encapsultaion w.r.t. OOP
car2.setModel('SUV');
document.getElementById('id1').innerHTML=car1.ageOfCar()+"----"+car2.ageOfCar()+"------"+car2.getModel()+"----";


/**
 * JS Class Inheritance:-
 *  To create a class inheritance, use the keyword 'extends'
 * 
 * A class created with a class inheritance inherits all the methods from another class
 */

class MyCar{
        /**
     * This constructor method is a special method:
     * It has to have the exact name "constructor"
     * It is executed automatically when a new object is created
     * It is used to intialize object properties
     * @param {*} brand 
     */
    constructor(brand){
        this.brand=brand;
    }

    displayInfo(){
        return 'My car brand name is ----'+this.brand;
    }

}
//Model class is a child class and its inheriting the properties and methods of parent class name MyCar
class Model extends MyCar{
    constructor(brand,mod){
        super(brand); //It refers to the parent class. By calling the super() method in the constructor method, we call the parents construtor method and gets access to the parents properties and methods
        this.mod=mod;
    }
    show(){
        return this.displayInfo() +'it is a --'+this.mod;
    }
}

let myCar= new Model('VOLVO','XC60');
document.getElementById('id2').innerHTML=myCar.show();

/**
 * Java Script static methods
 * Static class methods are defined on the class itself.
 * You cannot call a static method on an object , only on an object class
 */


 class Employee{
     constructor(name){
         this.name=name;
     }
     static greeting(x){
         return "Hello !!!"+x.name;
     }
 }
 
 let emp= new Employee('Joe');
// document.getElementById('id3').innerHTML=emp.greeting();// this not allowed in JS when your method inside a class is a static
 //document.getElementById('id3').innerHTML=Employee.greeting(); // This will work as we are trying to access the static method using class name
 document.getElementById('id3').innerHTML=Employee.greeting(emp); // Passing emp object as a parameter to the static method

 