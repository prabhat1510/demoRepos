/**
 * JS Function Call,Apply,Closures
 * OOPS in JS
 * Async- Callbacks,Asynchronous,Promises,Async/wait
 */
/**
 * call() method
 * In Javascript all functions are object methods
 * If a function is not a method of a JS object, it is a function of the global object
 * 
 * 
 *  */


 var employee={
    firstName:"Donald",
    lastName:"Trump",
    fullName: function(){
        return this.firstName+"   "+this.lastName;//this refers to the owner of the function
    }        
}
document.getElementById('id1').innerHTML=employee.fullName();

/**
 *  call() method is a predefined JS method
 * It can be used to invoke(call) a method with an owner object as an argument(parameter).
 */

var emp={
    fullName: function(){
        return this.firstName+"   "+this.lastName;//this refers to the owner of the function
    }        
}
var employee1={
    firstName:"Mike",
    lastName:"Douglas",
}
var employee2={
    firstName:"Shraddha",
    lastName:"Puri",
}
document.getElementById('id2').innerHTML=emp.fullName.call(employee1);


var emp1={
    fullName: function(dept,age){
        return this.firstName+"   "+this.lastName+" "+dept+"  "+age;//this refers to the owner of the function
    }        
}
//With call() an object can use a method belonging to another object
document.getElementById('id3').innerHTML=emp1.fullName.call(employee2,"IT",23);

/**
 * apply() method -
 *  The call() method takes arguments separately
 * The apply() method takes an arguments as an array
 */

document.getElementById('id4').innerHTML=emp.fullName.apply(employee2);

document.getElementById('id5').innerHTML=emp1.fullName.apply(employee1,["Sales",27]);

/**
 * Fucntion closures
 *  JS variables can belong to the local or global scope.
 * Global variables can be made local(private) with closures
 */
var z=4;
 function myFunc(){
     var z=3 //variable z is local to myFunc
     console.log("The value of  z inside myFunct---"+z);
    return z*z;
}

document.getElementById('id5').innerHTML=z+"-----------"+"---------"+myFunc();

/**
 * variables created without a declaration keyword(var,let or const) are always global, even if they are created inside a function.
 */
//outer function
function addition(){
    var count=0;
    //inner function
    function increment(){
        count+=1;
    }
    increment(); //calling or invoking increment function
    return count;
}  

document.getElementById('id6').innerHTML=addition();

/**
 * Self invoking function- what does this function do ?
 * The variable add is assigned to the return value of a self-invoking function.
 * The self-invoking function only runs once. It sets the count to zero(0), and returns a function expression.
 * This way add becomes a function. The wonderful part is that it can access the count in the parent scope.
 * This is called a JS closure, It makes it possible for a function to have private variables.
 * The count is protected by the scope of the anonymous function, and can only be changed using the add function
 */

 var add= (function (){
    var count=0;
    return function(){count+=1; return count;}
})();
//A closure is a function having access to the parent scope,even after the parent function has closed.
document.getElementById('id7').innerHTML=add()+"    "+ add()+"    "+add();