/**
 * Numbers-- 
 * 
 * var num =1234;
 * num.toString() -- returns 1234 from variable x
 * (1234).toString() -- returns 1234 from literal x
 * (15+25).toString() -- returns 40 from expression (15+25)
 */
var a=3.14;
var b=2020;
var num=1234;
document.getElementById('id1').innerHTML=num.toString()+"-----"+(1234).toString()+"------"+(15+25).toString();
var x=9.656
document.getElementById('id2').innerHTML=x.toExponential(2)+"-----"+x.toExponential()+"-----"+x.toExponential(6)
var y=9.6568957
document.getElementById('id3').innerHTML=y.toPrecision()+"------"+y.toPrecision(2)+"-----"+y.toPrecision(4)+"----"+y.valueOf()
var z=12344534643;
document.getElementById('id4').innerHTML=typeof(z)+"------"+(z.valueOf()+1)+"------"+typeof(z.valueOf())

var date= new Date("2020-10-24");
/**
 * Number(date)
 * It returns the number of milliseconds since 1.1.1970 . It also known as Epoch time
 */
document.getElementById('id5').innerHTML=date+"------"+new Date()+"------"+Number(date);
document.getElementById('id6').innerHTML=parseInt("10")+"------"+parseInt("10.55")+"------"+parseInt("10 20 30")+"------"+parseInt("10 years")+"------"+parseInt("years 20 ")+'----'+parseFloat('10.55')+'------'+parseFloat('10');
document.getElementById('id7').innerHTML=Number.MAX_VALUE+'----+'+Number.MIN_VALUE+'------'+Number.POSITIVE_INFINITY+'------'+Number.NEGATIVE_INFINITY+"-----"+(1/0)+"-----+"+(-1/0);

/**
 *  Java Scripts Arrays
 *  It is a special variable which can hold more than one value at a time.
 * 
 * Arrays index starts from 0,1 ... and ends with array length -1
 */
var festivals=["Diwali","Christmas","Dussehra","Holi","Eid"] ;
var festival1="Diwali";
var festival2="Holi";
var festival3="Eid";
var numbers=[5,2,6,7,8,9,10,11];
function myFunct(){
    return "Happy Dussehra";
}
// Using new keyword
var decimalNumbers=new Array(15.15,16.50,10.20);
document.getElementById('id8').innerHTML=typeof(festivals)+"-------"+typeof(numbers)+"------"+typeof(decimalNumbers);
festivals[2]="Sankranti";
document.getElementById('id9').innerHTML=festivals[0]+"-----"+festivals[3]+'----------------'+festivals[2]+'*************'+festivals;
var myArray=[Date.now(),festivals,myFunct()];
document.getElementById('id10').innerHTML=myArray[0]+"-----"+myArray[1]+"-----"+myArray[2]+"-----"+festivals.length+'-----'+festivals.sort()+'------'+festivals[festivals.length-1];
//Use of basic for loop to access array elements
var fLength=festivals.length;
var text='<ul>';
var i;
for(i=0;i<fLength;i++){
    text+='<li>'+festivals[i]+'</li>'; // text=text+'<li>'+festivals[i]+'</li>'
}
text+='</ul>';
document.getElementById('id11').innerHTML=text;
//Use of forEach- Array.forEach()
var text2 = '<ul>';
festivals.forEach(myFunction); // It calls a function for each array element. 
text2+='</ul>';
function myFunction(value){
    text2+='<li>'+value+'</li>';
}

document.getElementById('id12').innerHTML=text2 +'-------'+festivals.push('Easter')+'-------'+festivals+'------------'+festivals.pop()+'-----------'+festivals;
var s = festivals.shift();

document.getElementById('id13').innerHTML=s+'------'+festivals+'------'+festivals.unshift('Prabhat')+'------'+festivals+'--------'+(delete festivals[0])+'------------'+festivals;

var nums=[5,2,6,7,8,9,10,11];
var txt='';
nums.forEach(myFunction1)
/**function myFunction1(val1,index,array){
    txt=txt+val1+'<br>';
}*/
function myFunction1(val1){
    txt=txt+val1+'<br>';
}
document.getElementById('id13').innerHTML=txt;
/**
 * Array.map()-- 
 *          1. It creates a new array by performing a function on each array element.
 *          2. It does not execute the function for array elements without values.
 *          3. It does not change the original array
 * Array.filter() --- To filter out the elements or items of an array based on some constraint.
 * Array.reduce()--- It runs a function on each array element to produce (reduce it to) a single value. It works from left-to-right in the array. 
 */

 var num2=nums.map(myFunction2);
var num3= nums.filter(myFunction3);
 function myFunction2(value){
    return value*2;
 }

 function myFunction3(value){
    return value<8;
 }
 var sum=nums.reduce(myFunction4);
 
 function myFunction4(total,value){
    return total+value;
 }

 var numbers=[16,14,25,45,10,50];
 var eligibleToVote=numbers.find(myFunction5);
 function myFunction5(value){
    return value>18;
 }
 document.getElementById('id14').innerHTML=num2+'--------'+num3+'--------'+sum+'------------'+eligibleToVote;