var a= 15;
let b=20;
const c=35;
//You cannot reassign the value to a constant variable
//c=45;
document.getElementById('id2').innerHTML="a---"+a+"b---"+b+"c---"+(c+10);

//Arithmetic Operators
let d=15;
let e=5;
let f=0;
f=d+e;
document.getElementById('id3').innerHTML="add---"+f;
f=d-e;
document.getElementById('id4').innerHTML="sub---"+f;
f=d*e;
document.getElementById('id5').innerHTML="mul---"+f;
f=d**e;
document.getElementById('id6').innerHTML="exponentiation---"+f;
f=d/e;
document.getElementById('id7').innerHTML="division---"+f;
f=d%e;
document.getElementById('id8').innerHTML="modulus division---"+f;
f=++d;
document.getElementById('id9').innerHTML="increment---"+f;
f=--d;
document.getElementById('id10').innerHTML="decrement---"+f;
