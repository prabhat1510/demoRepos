console.log("Hello Everyone");
document.getElementById('demo').innerHTML="My First JS";
//window.alert("Hi I am doing good");
