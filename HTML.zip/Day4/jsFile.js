/**
 * Assignment Operators
*/
let d=15;
let e=5;
let f=0;
f=d+e;
document.getElementById('id1').innerHTML="add---"+f;
f+=d; // f=f+d
document.getElementById('id2').innerHTML="addition assignment operator---"+f;
f-=d; // f=f-d
document.getElementById('id3').innerHTML="subtraction assignment operator---"+f;

f*=d; // f=f*d
document.getElementById('id4').innerHTML="multiplication assignment operator---"+f;

f/=d; // f=f/d
document.getElementById('id5').innerHTML="division assignment operator---"+f;

f%=d; // f=f%d
document.getElementById('id6').innerHTML="modulus division assignment operator---"+f;

f<<=d; // f=f<<d
document.getElementById('id7').innerHTML="less than equals to assignment operator---"+f;
f>>=d; // f=f>>d
document.getElementById('id8').innerHTML="greater than equals to assignment operator---"+f;

var num=15; // number
var firstName="Donald"; // String 
var str={
	 lastName:"Trump",firstName:"Donald"
}; // object which has property or attribute namely firstName and lastName

document.getElementById('id9').innerHTML="type of variable num---"+typeof(num);
document.getElementById('id10').innerHTML="type of variable firstName---"+typeof(firstName);
document.getElementById('id11').innerHTML="type of variable num---"+typeof(str);
document.getElementById('id12').innerHTML="value  of str properties---"+str.lastName +"-----"+str.firstName;

//Declaration of the variable, JS has dynamic types
var y; // Now is undefined in JS . variable without a value is undefined
document.getElementById('id13').innerHTML="value of variable y ---"+y;
y=16; // initializing your variable y with 16
document.getElementById('id14').innerHTML="value of variable y ---"+y;
y="Nemanja";
document.getElementById('id15').innerHTML="value of variable y ---"+y;

var str1 = "Career Era";
var str2= "Career Era is good for learning 'Java Full Stack'";
var str3='Wish you all "Happy Dussehra"';
document.getElementById('id16').innerHTML="value of variable str1+str2+str3 ---"+str1+"---"+str2+"----"+str3;

//JS has only one type of numbers.
var y1=15.50;
var y2=15;
document.getElementById('id17').innerHTML="value of variable y1+y2 ---"+y1+"---"+y2+"----"+typeof(y1)+"----"+typeof(y2);
//Boolean data types which will have two values true or false
var l=15;
var m=15;
var n=16;
document.getElementById('id18').innerHTML="comparison of  --(l==m) ------(m==n)"+(l==m)+"-------"+(m==n);

// Javascript Arrays 
// Array items are separated by commas
//Array inedexe are zero based,
//            0(start)     1        2          3           4 (length-1)
var fruits=["apple","banana","strawberry","avacado","kiwi"];
document.getElementById('id19').innerHTML="comparison of  --fruits"+fruits+"-------"+typeof(fruits)+"------"+fruits[0]+'---------'+fruits[1]+'---------'+fruits[2]+'------'+fruits[3]+'---------'+fruits[4]+'---------'+fruits[5]+'----Length of an Array object fruits is -----'+fruits.length;

var p;
var fruit='';// Its an empty string. 
document.getElementById('id20').innerHTML="value of p and fruit------"+p+'--------------------------'+fruit+'-----'+typeof(fruit);

var employee={
    firstName:'Rakesh',lastName:'Sharma',age:40,salary:150000
};
document.getElementById('id21').innerHTML="value of employee object------"+employee+'---'+typeof(employee);
employee=null;
employee=undefined;
document.getElementById('id22').innerHTML="value of employee object------"+employee+'---'+typeof(employee);
document.getElementById('id23').innerHTML="difference between null and undefined in JS------"+(null == undefined)+'---'+(null===undefined);

//Complex Data

document.getElementById('id24').innerHTML="type of Complex DaTA------"+typeof{name:'Rakesh',age:25} +'------'+typeof(function myFunc(){});
/**
 * JavaScript Functions:-
 * Its a block of code designed to perform a particular task.
 * It is executed when something invokes it (calls it).
 * 
 * Why function?
 * 1.Resuablitiy 
 * 2.Cleaner code
 * 
 * Function names can contain letters, digits, underscores, and dollar signs(same rules as variables)
 */
//Function definition of addition who has num1 and num2 as parameters.
function addition(num1,num2){
    sum=num1+num2;
    return sum;
}
/**
 * Function arguments are the values received by the function when it is invoked
 */
var result=addition(15,16);
function displayMsg(){
    
    return "Happy Learning";
}
document.getElementById('id25').innerHTML="Sum of two numbers------"+result+'-----------'+addition(20,5)+'------'+displayMsg();
//person object having properties as firstName,lastName,age,salary and method or function as fullName
var person={
    firstName:'Rakesh',
    lastName:'Sharma',
    age:40,
    salary:150000,
    fullName: function(){
        //this keyword refers to the owner of the function
        return this.firstName+" "+this.lastName;
    }
};
document.getElementById('id26').innerHTML="Accessing person object------"+typeof(person)+'---------'+person.fullName()+'-----'+person.fullName;
// As a developer we should not use new keyword to creat String,Number,Boolean object.
var a= new String();// Declaring a as a String object
var b=new Number();
var c=new Boolean();
document.getElementById('id27').innerHTML=typeof(a)+'---'+typeof(b)+'---'+typeof(c);


/**
 * 
 * JS Events
 * HTML events are things that happen to HTML elements
 * When JS is used in HTML pages, JS can react on these events
 * HTML events:-
 * 1. onclick  - the user clicks an HTML element
 * 2. onchange -  an html element has been changed
 * 3. onmouseover - The user moves the mouse over an HTML element
 * 4. onmouseout -  The user moves the mouse away from an HTML element
 * 5. onkeydown - The user pushes a keyboard key
 * 6. onload - The browser has finished loading the page
 * 
 */

 function displayInfo(){
    document.getElementById('id28').innerHTML="Welcome to JS Events programming";   
 }
// 01234567891011121314151617181920.... index in strings also starts from zero to length minus one 
 var str2="Hello How are you ?\"I am very\
  good\"";
 var lengthOfStr2=str2.length;//length is a built in property
 var pos=str2.indexOf("?");

 document.getElementById('id29').innerHTML=lengthOfStr2+'------'+str2+"-------"+pos+'----lastIndexOf'+str2.lastIndexOf('How',7)+"----search----"+str2.search("I");

            // 0123456789
 var fruitStr="Apple, Banana, Mango";
 document.getElementById('id30').innerHTML=fruitStr.substring(3,10)+'----------slice--------'+fruitStr.slice(7,13)+'--------'+fruitStr.slice(-13,-6)+'-----'+fruitStr.substr(7,9)+'--------'+fruitStr.replace("Banana","Kiwi")+'----'+fruitStr.toLowerCase()+'----'+fruitStr.toUpperCase()+"Hello".concat("Good to see you");