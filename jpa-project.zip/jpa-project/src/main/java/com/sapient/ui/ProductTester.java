package com.sapient.ui;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Scanner;

import com.sapient.service.Product;
import com.sapient.service.ProductService;
import com.sapient.service.ProductServiceImpl;

public class ProductTester {
	private static ProductService service=new ProductServiceImpl();

	private static Scanner scanner=	new Scanner(System.in);	

	public static void main(String[] args) {
		while(true) {
			try {
				System.out.println("Enter 1.add product 2. get product 3. get all products"
						+ "4. update product 5. delete product");
				int option= Integer.parseInt(scanner.nextLine());
				switch(option) {
				case 1: Product product=getProductDetails();
				Integer productId= service.addNewProduct(product);
				System.out.println(productId);
				break;
				case 2: System.out.println("Enter product id: ");
				productId= Integer.parseInt(scanner.nextLine());
				product=service.getProductById(productId);
				System.out.println(product);
				break;	
				case 3: List<Product> productList=service.getAllProducts();		
				productList.stream().forEach(System.out::println);
				break;
				case 4: System.out.println("Enter product id: ");
				productId= Integer.parseInt(scanner.nextLine());
				product=service.getProductById(productId);
				getUpdatedProductDetails(product);
				productId=service.updateProduct(product);
				System.out.println("Product:"+productId+" updated");
				break;
				case 5: System.out.println("Enter product id: ");
				productId= Integer.parseInt(scanner.nextLine());
				productId=service.deleteProduct(productId);
				System.out.println("Product:"+productId+" deleted");
				default: System.out.println("Invalid option"); break;
				}
			}catch(Exception e) {
				e.printStackTrace();
			}
		}

	}

	private static void getUpdatedProductDetails(Product product) {
		System.out.println("Enter product price: ");
		product.setProductPrice(Double.parseDouble(scanner.nextLine()));

	}

	private static Product getProductDetails() {
		Product product = new Product();
		System.out.println("Enter product name: ");
		product.setProductName(scanner.nextLine());
		System.out.println("Enter product description: ");
		product.setDescription(scanner.nextLine());
		System.out.println("Enter Expiry date(dd/mm/yyyy): ");
		String expdate= scanner.nextLine();
		SimpleDateFormat dateFormat=new SimpleDateFormat("dd/MM/yyyy");
		try {
			product.setExpiryDate(dateFormat.parse(expdate));
		} catch (ParseException e) {			
			e.printStackTrace();
		}
		System.out.println("Enter product price: ");
		product.setProductPrice(Double.parseDouble(scanner.nextLine()));
		return product;
	}



}
