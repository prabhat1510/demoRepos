package com.sapient.beanscope.beans;

public interface PrototypeBean {

}
