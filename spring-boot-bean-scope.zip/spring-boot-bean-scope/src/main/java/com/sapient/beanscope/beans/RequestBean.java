package com.sapient.beanscope.beans;

public interface RequestBean {

	public void printMessage();
}
