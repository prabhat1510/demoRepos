package com.sapient.beanscope.beans;

public interface SessionBean {

	public void printMessage();

}
