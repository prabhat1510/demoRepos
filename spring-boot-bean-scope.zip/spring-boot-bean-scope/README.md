# Spring Bean Scope Test with a Spring Boot REST API Application

Details of this project is available at <a href=""> my github repo</a>