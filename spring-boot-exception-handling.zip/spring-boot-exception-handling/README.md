# Spring Boot @ControllerAdvice & @ExceptionHandler example

## Run Spring Boot application
```
mvn spring-boot:run
```

