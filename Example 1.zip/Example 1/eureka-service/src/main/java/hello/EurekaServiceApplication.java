package hello;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

/*
 * Objective: 
 * The process of standing up and consuming the Netflix Eureka service registry.
 * 
 * Setup a Netflix Eureka service registry and then build a client that both registers itself with the registry
 *  and uses it to resolve its own host. A service registry is useful because it enables client-side load-balancing and decouples
 *  service providers from consumers without the need for DNS.
 */

/*
 * You’ll first need a Eureka Service registry. You can use Spring Cloud’s @EnableEurekaServer to stand up a registry 
 * that other applications can talk to. This is a regular Spring Boot application with one annotation added to 
 * enable the service registry.
 */

@EnableEurekaServer
@SpringBootApplication
public class EurekaServiceApplication {
    
    public static void main(String[] args) {
        SpringApplication.run(EurekaServiceApplication.class, args);
    }
}
