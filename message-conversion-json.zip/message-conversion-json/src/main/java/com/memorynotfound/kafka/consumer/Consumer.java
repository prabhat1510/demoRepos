package com.memorynotfound.kafka.consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Service;

import com.memorynotfound.kafka.Foo;

@Service
public class Consumer {
	private final Logger logger = 
			LoggerFactory.getLogger(Consumer.class);
	@KafkaListener(topics =  "${app.topic.example}", groupId = "group_id")
	public void consume(Message<Foo> message){
		logger.info(String.format("$$ -> Consuming Message ->"
				+ " %s",message.getPayload()));
	}
}