let modules=[{
    name:'ruby',
    id:1,
    description:'introduction to ruby and ruby objects',
    instructors:[
      {name:'Mazen',id:1,favorite_game:'metal gear',url:'https://images.app.goo.gl/y5tLE61vg3vABcmq7'},
      {name:'Sylwia',id:2,favorite_game:'minecraft',url:'https://images.app.goo.gl/meVgyfWmStzdBhKQ9'},
      {name:'Ian',id:3,favorite_game:'grand theft auto',url:'https://images.app.goo.gl/B8Gpt9BjiuGyb3ey6'}
    ]
  },{
    name:'ruby on rails',
    id:2,
    description:'introduction to active records and ruby on rails framework',
    instructors:[
      {name:'Rei',id:1,favorite_game:'fornite',url:'https://images.app.goo.gl/t7LjYctCSzF9nSDc8'},
      {name:'Sylwia',id:2,favorite_game:'minecraft',url:'https://images.app.goo.gl/meVgyfWmStzdBhKQ9'},
      {name:'Annie',id:3,favorite_game:'overwatch',url:'https://images.app.goo.gl/Wyh2fmRkqAu5WLqNA'},
      {name:'Ian',id:4,favorite_game:'grand theft auto',url:'https://images.app.goo.gl/B8Gpt9BjiuGyb3ey6'}
    ]
  },{
    name:'javascripts',
    id:3,
    description:'introduction to javascripts and DOM manipulation',
    instructors:[
      {name:'Rei',id:1,favorite_game:'fornite',url:'https://images.app.goo.gl/t7LjYctCSzF9nSDc8'},
      {name:'Sylwia',id:2,favorite_game:'minecraft',url:'https://images.app.goo.gl/meVgyfWmStzdBhKQ9'},
      {name:'Eric',id:3,favorite_game:'call of duty',url:'https://images.app.goo.gl/eXoVyBjz9NCGgott8'},
      {name:'Ian',id:4,favorite_game:'grand theft auto',url:'https://images.app.goo.gl/B8Gpt9BjiuGyb3ey6'}
    ]
  }]
  
  module.exports = {
    modules
  }