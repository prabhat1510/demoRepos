import React, { Component } from 'react';

export default class Home  extends Component {
   
    render() { 
        return (
            <h1>
              {'Home Component (by default)'}
            </h1>
          );
    }
}
 
