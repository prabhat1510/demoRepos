package com.designpatterndemo.cake;

import java.io.File;

public class XMLFileWriterDemo {

		public void pdfFileWriter(File file) {
			//TODO code to write pdfFileWriter
		}
	
}
