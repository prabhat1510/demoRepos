package com.designpatterndemo.cake;

public interface Factory {
	Cake createCake(String cakeName);
}
