/**
 * 
 */
package com.designpatterndemo.factory;

/**
 * @author Admin
 *
 */
public class Line implements Shape {

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("Line Drawn");
	}

}
