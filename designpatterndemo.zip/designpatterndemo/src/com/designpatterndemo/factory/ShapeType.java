/**
 * 
 */
package com.designpatterndemo.factory;

/**
 * @author Admin
 *
 */
public enum ShapeType {
	LINE,
    CIRCLE,
    RECTANGLE,
    TRIANGLE
}
