/**
 * 
 */
package com.designpatterndemo.factory;

/**
 * @author Admin
 *
 */
public interface Shape {
	void draw();
}
