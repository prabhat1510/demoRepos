package com.sapient.trg.dao;

public interface QueryMapper {
	public static final String GET_CUSTOMER_BY_ID= 
			"select * from customer_sapient where customer_id=?";
	public static final String GET_ALL_CUSTOMERS=
			"select * from customer_sapient";
	public static final  String ADD_CUSTOMER=
			"{call add_customer(?,?,?,?)}";
	public static final String UPDATE_CUSTOMER=
			"update customer_sapient set customer_name=?,birthdate=?,mobile=?,email=? where customer_id=?";
	
	public static final String DELETE_CUSTOMER="delete customer_sapient where customer_id=?";
}
