package com.sapient.trg.utility;

import java.sql.Connection;
import java.sql.SQLException;

public class TestConnection {

	public static void main(String[] args) {
		try(
				Connection  connection	=
							MySQLDataSource.getMySQLDataSource()
							.getConnection();
			) {			
				if(connection != null) {
					System.out.println("Connected..");
				}else {
					System.out.println("Unable to connect");
				}
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}

	}


