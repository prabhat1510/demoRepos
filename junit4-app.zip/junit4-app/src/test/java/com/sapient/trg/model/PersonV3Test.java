package com.sapient.trg.model;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

public class PersonV3Test {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("Global initialization");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("Clean-up");
	}
	
	@Test
	public void dummyMethod() {
		
	}

}
