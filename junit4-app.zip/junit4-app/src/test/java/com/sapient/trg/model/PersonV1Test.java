package com.sapient.trg.model;

import static org.junit.Assert.*;

import org.junit.Test;

public class PersonV1Test {

	@Test(expected=IllegalArgumentException.class)
	public void testPersonForNulls() {
		Person person=new Person(null,null);	
		
	}

}
