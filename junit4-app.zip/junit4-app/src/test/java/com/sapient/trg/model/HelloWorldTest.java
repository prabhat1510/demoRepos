package com.sapient.trg.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;



public class HelloWorldTest {
    private HelloWorld helloWorld;
    
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("BeforeClass executed");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("AfterClass executed");
	}

	@Before
	public void setUp() throws Exception {
		helloWorld=new HelloWorld("Hello World!");
		System.out.println("Executed before each test method");
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("Executed after each test method");
	}

	@Test
	public void testGetGreetings() {
		//HelloWorld helloWorld=new HelloWorld("Hello World!");
		assertEquals("Hello World!",helloWorld.getGreetings());
	}
	
	
	@Test
	public void testGetGreetingsForNull() {
		HelloWorld helloWorld= new HelloWorld();
		assertNull(helloWorld.getGreetings());
	}

	
	@Test
	public void testIsEmpty() {
		HelloWorld helloWorld= new HelloWorld();
		assertTrue(helloWorld.isEmpty());
	}
	
	@Ignore
	@Test
	public void testIsNotEmpty() {		
		assertFalse(helloWorld.isEmpty());
	}
	
	@Test
	public void verifyHelloWorld() {
		HelloWorld helloWorld1=helloWorld;
		assertSame("Both refering to same object",
				helloWorld,helloWorld1);
	}
	
	
	
	@Test(expected=ArithmeticException.class)
	public void testVerifyGreeting() {
		HelloWorld helloWorld=new HelloWorld();
		assertNull(helloWorld.verifyGreeting());
	}

	
	@Test(timeout=1000L)
	public void testSampleGreeting() {
		assertEquals("Hello",helloWorld.sampleGreeting());
	}

}
