package com.sapient.trg.model;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class PersonV2Test {
	private Person person;
	
	@Before
	public void beforeMethod() {
		person= new Person("Rohit","Sharma");
	}

	@Test
	public void testGetFullName() {
		assertEquals("Rohit Sharma",person.getFullName());
	}

	@Test
	public void testGetFirstName() {
		assertEquals("Rohit",person.getFirstName());
	}

	@Test
	public void testGetLastName() {
		assertNotEquals("Rohit",person.getLastName());
	}

}
