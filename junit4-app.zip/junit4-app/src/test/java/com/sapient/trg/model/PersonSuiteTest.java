package com.sapient.trg.model;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({
		com.sapient.trg.model.PersonV1Test.class,
		com.sapient.trg.model.PersonV2Test.class,
		com.sapient.trg.model.PersonV3Test.class
})
public class PersonSuiteTest {
	

}
