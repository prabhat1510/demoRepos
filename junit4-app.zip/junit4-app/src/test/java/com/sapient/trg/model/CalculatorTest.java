package com.sapient.trg.model;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;


@RunWith(Parameterized.class)
public class CalculatorTest {
	private int operand1;
	private int operand2;
	
	@Parameterized.Parameters
	public static Collection data() {
		return Arrays.asList(new Object[][] {
			{4,5},{1,1},{1,0},{0,1}
		});
	}
		
	public CalculatorTest(int operand1, int operand2) {
		super();
		this.operand1 = operand1;
		this.operand2 = operand2;
	}

	@Test
	public void testSquared() {
		assertEquals(operand1*operand1,
				Calculator.squared(operand1));
	}

	@Test(expected=RuntimeException.class)
	public void testDivide() {		
			assertEquals(operand1/operand2,
					Calculator.divide(operand1,operand2));
			
	}

	@Test
	public void testMultiply() {
		assertEquals(operand1*operand2,
				Calculator.multiply(operand1,operand2));
	}

}
