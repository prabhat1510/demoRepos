package com.sapient.trg.model;

public class Calculator{
	public static int squared(int x){
		return x * x;
	}
	
	public static int divide(int dividend,int divisor){
		int result;
		result=dividend/divisor;
		return result;
	}
	
	public static int multiply(int x, int y) {
		return x*y;
	}
}