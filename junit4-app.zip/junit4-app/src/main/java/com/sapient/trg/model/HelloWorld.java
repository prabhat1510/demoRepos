package com.sapient.trg.model;


public class HelloWorld {
	private String greetings;
	
	public HelloWorld(){
		
	}
	
	public HelloWorld(String greetings){
		this.greetings=greetings;
	}

	public String getGreetings() {
		return greetings;
	}

	public void setGreetings(String greetings) {
		this.greetings = greetings;
	}	
	
	public boolean isEmpty(){
		if(this.greetings==null){
			return true;
		}
		return false;
	}
	
	public String verifyGreeting(){
		if(this.greetings==null){
			throw new NullPointerException("The property,greetings is null");
		}
		return this.greetings;
	}
	
	public String sampleGreeting(){
		try {
			Thread.sleep(1800);
		} catch (InterruptedException e) {			
			e.printStackTrace();
		}
		return "Hello";
	}
	
	
}
