package com.sapient.servicedaodemo.service;

import java.util.List;

import com.sapient.servicedaodemo.model.Transaction;

public interface TransactionService {

    public List<Transaction> findAllTransactions();

    public String screenTransactionById(int theId);

    public Transaction findTransactionById(int theId);

    public Transaction saveTransaction(Transaction theTransaction);

    public int deleteTransactionById(int theId);

}
