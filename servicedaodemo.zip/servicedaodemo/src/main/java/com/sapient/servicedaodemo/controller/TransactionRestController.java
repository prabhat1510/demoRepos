package com.sapient.servicedaodemo.controller;

import org.springframework.web.bind.annotation.RestController;

import com.sapient.servicedaodemo.service.TransactionService;

@RestController
public class TransactionRestController {

	private TransactionService  transactionService;
}
