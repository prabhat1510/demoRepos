package com.sapient.servicedaodemo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.sapient.servicedaodemo.model.Transaction;
import com.sapient.servicedaodemo.service.TransactionService;

@RestController
@RequestMapping("/api")
public class TransactionRestController {

	private TransactionService  transactionService;
	@Autowired
	public TransactionRestController(TransactionService transactionService) {
		super();
		this.transactionService = transactionService;
	}
	@RequestMapping(value = "/transactions", method= RequestMethod.GET)
	public ResponseEntity<List<Transaction>> findAll(){
			List<Transaction> transactions =transactionService.findAllTransactions();
			return new ResponseEntity<>(transactions, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/transactions/{transactionId}", method= RequestMethod.GET)
	public String screenTransaction(@PathVariable int transactionId) {
		String transaction = transactionService.screenTransactionById(transactionId);

        return transaction;
	}
	
	//For adding a transaction
    @RequestMapping(value = "/transactions", method = RequestMethod.POST)
    public Transaction addTransaction(@RequestBody Transaction theTransaction){

        return (transactionService.saveTransaction(theTransaction));
    }
    
  //For updating a transaction
    @RequestMapping(value = "/transactions", method = RequestMethod.PUT)
    public Transaction updateTransaction(@RequestBody Transaction theTransaction){
        Transaction transaction = transactionService.findTransactionById(theTransaction.getId());
        if (transaction == null) {
            throw new RuntimeException("Transaction to update doesn't exist");
        }
        return (transactionService.saveTransaction(theTransaction));
    }

    //For deleting a transaction
    @RequestMapping(value = "/transactions/{transactionId}", method = RequestMethod.DELETE)
    public String deleteTransaction(@PathVariable int transactionId){
        Transaction tempTransaction = transactionService.findTransactionById(transactionId);
        if(tempTransaction == null){
            throw new RuntimeException("Transaction Id not found");
        }
        transactionService.deleteTransactionById(transactionId);
        return "deleted transaction id " + transactionId;

    }
    

	
	
}
