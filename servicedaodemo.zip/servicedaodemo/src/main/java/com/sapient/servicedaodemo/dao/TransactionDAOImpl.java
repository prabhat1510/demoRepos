package com.sapient.servicedaodemo.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.sapient.servicedaodemo.model.Transaction;

@Repository
public class TransactionDAOImpl implements TransactionDAO {

	private EntityManager entityManager ;
	
	@Autowired
	public TransactionDAOImpl(EntityManager entityManager) {
		super();
		this.entityManager = entityManager;
	}

	@Override
	public List<Transaction> getAllTransactions() {
		// TODO Auto-generated method stub
		Query query = entityManager.createQuery("from Transaction");
		
		return null;
	}

	@Override
	public Transaction findTransactionById(int theId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Transaction saveTransaction(Transaction theTransaction) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteTransactionById(int theId) {
		// TODO Auto-generated method stub

	}

}
