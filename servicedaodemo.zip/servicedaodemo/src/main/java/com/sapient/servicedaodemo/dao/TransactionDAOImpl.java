package com.sapient.servicedaodemo.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.sapient.servicedaodemo.model.Transaction;

@Repository
public class TransactionDAOImpl implements TransactionDAO {

	private EntityManager entityManager ;
	
	@Autowired
	public TransactionDAOImpl(EntityManager entityManager) {
		super();
		this.entityManager = entityManager;
	}

	@Override
	public List<Transaction> getAllTransactions() {
		
		Query query = entityManager.createQuery("select * from Transaction");
		List<Transaction> transactions= query.getResultList();
		return transactions;
	}

	@Override
	public Transaction findTransactionById(int theId) {
		Transaction transaction = entityManager.find(Transaction.class,theId);
        return transaction;
	}

	@Override
	public Transaction saveTransaction(Transaction transaction) {
		Transaction dbTransaction = entityManager.merge(transaction);
        transaction.setId(dbTransaction.getId());
        return transaction;
	}

	@Override
	public void deleteTransactionById(int theId) {
		// TODO Auto-generated method stub
		Query query = entityManager.createQuery("delete from Transaction where id=: transactionId");
		query.setParameter("transactionId", theId);
		query.executeUpdate();
	}

}
