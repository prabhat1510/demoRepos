module designpatterndemotwo {
	requires org.slf4j;
}