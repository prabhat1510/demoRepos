package designpatterndemotwo.facade;

public class McDonalds implements Franchise {
	public void Option() {
		System.out.println("McDonalds");
	}

	public void Cost() {
		System.out.println("Rs 90,00,000");
	}
}
