package designpatterndemotwo.facade;

public class KFC implements Franchise {
	public void Option() {
		System.out.println("KFC");
	}

	public void Cost() {
		System.out.println("Rs 1,00,00,000");
	}
}
