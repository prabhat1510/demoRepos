package designpatterndemotwo.facade;

public interface Franchise {
    public void Option();
    public void Cost();
}
