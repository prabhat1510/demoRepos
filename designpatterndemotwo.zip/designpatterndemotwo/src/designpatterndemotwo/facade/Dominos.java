package designpatterndemotwo.facade;

public class Dominos implements Franchise {
	public void Option() {
		System.out.println("Dominos");
	}

	public void Cost() {
		System.out.println("Rs 80,00,000");
	}
}