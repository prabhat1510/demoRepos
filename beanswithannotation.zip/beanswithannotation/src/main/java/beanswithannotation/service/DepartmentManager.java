package beanswithannotation.service;

import beanswithannotation.bean.Department;

public interface DepartmentManager {
	public Department create();
}
