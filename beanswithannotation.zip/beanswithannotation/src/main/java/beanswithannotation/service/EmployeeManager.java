package beanswithannotation.service;

import beanswithannotation.bean.Employee;

public interface EmployeeManager {

	public Employee create();
	
}
